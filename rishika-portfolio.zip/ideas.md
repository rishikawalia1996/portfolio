# Rishika Walia Portfolio — Design Ideas

## Approach 1: Editorial Noir

<response>
<text>
**Design Movement:** Swiss International Typographic Style meets contemporary editorial noir

**Core Principles:**
- Stark contrast between black and off-white creates visual authority
- Typography IS the design — letterforms carry structural weight
- Negative space is as important as content
- Grid breaks are intentional and dramatic

**Color Philosophy:** Near-black (#0D0D0D) backgrounds with warm white (#F5F2EE) text. A single accent — a dusty rose or terracotta — used sparingly for hover states and micro-details. The restraint of color makes every accent feel deliberate.

**Layout Paradigm:** Asymmetric editorial grid. Navigation floats left as a vertical sidebar on desktop. Work section uses a masonry-inspired staggered grid where tiles vary in size — some full-width, some half, creating rhythm and tension.

**Signature Elements:**
- Thin horizontal rules (1px) as section dividers with generous breathing room
- Oversized project numbers (01, 02, 03) as decorative typographic anchors
- Cursor-following spotlight effect on project thumbnails

**Interaction Philosophy:** Deliberate and slow — hover reveals are smooth 600ms transitions. Modal overlays use a full-screen takeover with cinematic entrance.

**Animation:** Staggered text reveal on scroll (letters slide up from below). Project tiles fade in with a slight upward drift. Modal opens with a scale-from-center effect.

**Typography System:** Cormorant Garamond (display, ultra-light 300) + DM Sans (body, regular 400). Headings at 80-120px, body at 16-18px.
</text>
<probability>0.08</probability>
</response>

---

## Approach 2: Warm Minimalist Editorial (SELECTED)

<response>
<text>
**Design Movement:** Warm Scandinavian Minimalism meets high-end editorial design

**Core Principles:**
- Warmth through texture and tone — not cold sterile white but warm cream and stone
- Typography-led hierarchy with generous line heights
- Work is the hero — everything else steps back
- Restrained but not cold

**Color Philosophy:** Background: warm off-white (#FAF8F5). Foreground: deep charcoal (#1A1A1A). Accent: a single warm black used for interactive states. Secondary text in warm mid-grey (#8A8A8A). No gradients, no color splashes — purity of palette.

**Layout Paradigm:** Asymmetric two-column grid that shifts between sections. Work section uses a mixed-size grid (like dougrodas.com) — alternating large and small tiles in a 2-column layout with varying heights. About section uses a split layout — photo on left, text on right with generous margin.

**Signature Elements:**
- Thin serif display font for section labels (small, uppercase, tracked)
- Project tiles with a subtle warm overlay on hover revealing project info
- Animated underline links that draw from left to right

**Interaction Philosophy:** Quiet confidence — interactions are smooth and never jarring. Hover states are warm and inviting, not aggressive.

**Animation:** On-scroll reveal using Framer Motion (fade + translateY). Navigation has a subtle blur backdrop. Project modal slides in from the right.

**Typography System:** Playfair Display (headings, 700) + Outfit (body, 400/500). Section labels in Outfit uppercase tracked. Hero at 96px, section headers at 56px, body at 17px.
</text>
<probability>0.07</probability>
</response>

---

## Approach 3: Kinetic Type Portfolio

<response>
<text>
**Design Movement:** Post-digital brutalism softened with luxury restraint

**Core Principles:**
- Motion as a design element — the page feels alive
- Typographic scale creates drama without color
- Raw grid exposed intentionally
- Tension between structure and freedom

**Color Philosophy:** Pure white (#FFFFFF) with jet black (#111111). One accent color — a deep forest green (#1C3A2A) — used only for the hero section and hover states. The green grounds the palette in something organic.

**Layout Paradigm:** Full-viewport sections. Work section uses a horizontal scroll carousel on desktop, vertical stack on mobile. Each project tile is a full-bleed image with text overlay.

**Signature Elements:**
- Animated hero text that cycles through descriptors (Designer / Creative Lead / Art Director)
- Project tiles with a color-tinted overlay matching each brand's palette
- Sticky section counter (01/03, 02/03) visible during scroll

**Interaction Philosophy:** Energetic but controlled — interactions feel premium, not playful. The site rewards exploration.

**Animation:** Hero text morphs between words with a clip-path reveal. Scroll-triggered parallax on project images. Navigation items have a staggered entrance on page load.

**Typography System:** Syne (display, 800) + Satoshi (body, 400). Extreme size contrast — 140px hero down to 15px captions.
</text>
<probability>0.06</probability>
</response>

---

## Selected Approach: Warm Minimalist Editorial

Choosing **Approach 2** — Warm Minimalist Editorial. This aligns perfectly with Rishika's positioning as a senior creative: warm, confident, and letting the work speak. The Playfair Display + Outfit pairing creates editorial authority without being cold or clinical.
